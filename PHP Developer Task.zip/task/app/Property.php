<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Property extends Model
{
    //
    protected $fillable = ['id', 'Name', 'Price', 'Bedrooms', 'Storeys', 'Garages'];	






    protected $hidden = [
        'timestamps', 'remember_token',
    ];
}
